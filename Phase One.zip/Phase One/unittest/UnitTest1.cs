﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Phase_One;
namespace unittest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [Timeout(5000)]
        public void TestMethodfueleconomy()          
        {

            int km = 100;
            int fuel = 10;
            int expected = 10;

            var test = new vehicle(fuel,km);

            int actual = test.fueleconomy(km, fuel);

            Assert.AreEqual(expected, actual);


        }
    }
}
