﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    public class fuelpurchase
    {
        private double fueleconomy;
        private int totalservice;
        private int fuelused;
      //constructors

        public fuelpurchase()
        {

        }

        public fuelpurchase(double pfueleconomy,int ptotalservice, int pfuelused)
        {
            fueleconomy = pfueleconomy;
            totalservice = ptotalservice;
            fuelused = pfuelused;
            
        }
        //get sets
        public double getfueleconomy
        {
            get { return (fueleconomy); }
            set { fueleconomy = value; }
        }

        public int getotalservice
        {
            get { return (totalservice); }
            set { totalservice = value; }
        }

        public int getfuelused
        {
            get { return (fuelused); }
            set { fuelused = value; }
        }

       

       
    }
}
