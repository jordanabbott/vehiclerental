﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    public class Journey
    {    
        private int distancetraveled = 0;
     
        //constructors

        public Journey()
        {}
        public Journey(int pdistancetraveled)
        {          
            distancetraveled = pdistancetraveled;
        }

        //get sets

        public int getdistancetraveled
        {
            get { return (distancetraveled); }
            set { distancetraveled = value; }
        }


        public override string ToString()     
        {
            return " Distance traveled  " + this.distancetraveled;
        }
    }
}
