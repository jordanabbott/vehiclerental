﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    class PerKmRental
    {
        private int kmtraveled;
        private int costperkm = 1;

        //constructors
        public PerKmRental()
        { }

        public PerKmRental(int pkmtravled, int pcostperkm)
        {
            kmtraveled = pkmtravled;
            costperkm = pcostperkm;
        }

        //get sets
        public int getkmtraveled
        {
            get { return (kmtraveled); }
            set { kmtraveled = value; }
        }

        public int getcostperkm
        {
            get { return (costperkm); }
            set { costperkm = value; }
        }

    }
}
