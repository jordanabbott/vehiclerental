﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    public class vehicle
    {
        private string make;
        private string model;
        private string reg;
        private string year;
        private int totalkm = 0;
        private int servicekm = 0;
        int totalservices;
        bool reqService = false;
        int totalfuel;

        //public int fueleconomy()
        //{
        //    throw new NotImplementedException();
        //}




        //constructors
        public vehicle(string pmake, string pmodel, string pregistration, string pyear)
        {
            make = pmake;
            model = pmodel;
            reg = pregistration;
            year = pyear;
        

        }
        public vehicle(int ptotalkm, int ptotalfuel)
        {
            totalfuel = ptotalfuel;
            totalkm = ptotalkm;
        }
        public vehicle()
        {
        
        }

        //get sets
        public int gettotalfuel
        {
            get { return (totalfuel); }
            set { totalfuel = value; }
        }

        public int getservicekm
        {
            get { return (servicekm); }
            set { servicekm = value; }
        }
        public int gettotalservice
        {
            get { return (totalservices); }
            set { totalservices = value; }
        }
        public int getotalkm
        {
            get { return (totalkm); }
            set { totalkm = value; }
        }
        public string getmake
        {
            get{ return (make); }                   
            set {make = value;}
        }

        public string getmodel
        {
            get { return (model); }
            set { model = value; }
        }

        public string getreg
        {
            get { return (reg); }
            set { reg = value; }
        }

        public string getyear
        {
            get { return (year); }
            set { year = value; }
        }

        public bool getReqService
        {
            get { return (reqService); }
            set { reqService = value; }
        }

        public void addjourney(Journey pJourney)
        {
            totalkm += pJourney.getdistancetraveled;
        }

        public void requiresService(Service pService)
        {
            reqService = pService.getservice;
        }

        public override string ToString()
        {
            return this.make + " " + this.model + " " + this.reg + " " + this.year + " " + totalkm;


        }
        public int fueleconomy(int testkm, int testfuel)
        {
            int fueleco = testkm / testfuel;
            return fueleco;
        }

    }
    
   
}
