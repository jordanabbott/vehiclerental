﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    class PerDayRental
    {
        private int daysrented;
        private int costperday = 100;
        //constructors
        public PerDayRental()
        { }

        public PerDayRental(int pdaysrented, int pcostperday)
        {
            daysrented = pdaysrented;
            costperday = pcostperday;
        }
        //get sets

        public int getdaysrented
        {
            get { return (daysrented); }
            set { daysrented = value; }
        }

        public int getcostperday
        {
            get { return (costperday); }
            set { costperday = value; }
        }

    }
}
