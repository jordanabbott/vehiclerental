﻿namespace Phase_One
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Savebtn = new System.Windows.Forms.Button();
            this.vehiclelbl = new System.Windows.Forms.Label();
            this.vehiclereglbl = new System.Windows.Forms.Label();
            this.vehicleyearlbl = new System.Windows.Forms.Label();
            this.modellbl = new System.Windows.Forms.Label();
            this.vehicletxt = new System.Windows.Forms.TextBox();
            this.modeltxt = new System.Windows.Forms.TextBox();
            this.yeartxt = new System.Windows.Forms.TextBox();
            this.regnumtxt = new System.Windows.Forms.TextBox();
            this.outputlist = new System.Windows.Forms.ListBox();
            this.journeytitle = new System.Windows.Forms.Label();
            this.distancetraveledlbl = new System.Windows.Forms.Label();
            this.vehicletitle = new System.Windows.Forms.Label();
            this.fuelusedlbl = new System.Windows.Forms.Label();
            this.fuelusetxt = new System.Windows.Forms.TextBox();
            this.traveledtxt = new System.Windows.Forms.TextBox();
            this.vehiclelistbox = new System.Windows.Forms.ComboBox();
            this.Addbtn = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.daysrentedtxt = new System.Windows.Forms.TextBox();
            this.Servicebtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Savebtn
            // 
            this.Savebtn.Location = new System.Drawing.Point(592, 166);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(75, 23);
            this.Savebtn.TabIndex = 0;
            this.Savebtn.Text = "Save";
            this.Savebtn.UseVisualStyleBackColor = true;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // vehiclelbl
            // 
            this.vehiclelbl.AutoSize = true;
            this.vehiclelbl.Location = new System.Drawing.Point(13, 67);
            this.vehiclelbl.Name = "vehiclelbl";
            this.vehiclelbl.Size = new System.Drawing.Size(72, 13);
            this.vehiclelbl.TabIndex = 2;
            this.vehiclelbl.Text = "Vehicle Make";
            // 
            // vehiclereglbl
            // 
            this.vehiclereglbl.AutoSize = true;
            this.vehiclereglbl.Location = new System.Drawing.Point(245, 67);
            this.vehiclereglbl.Name = "vehiclereglbl";
            this.vehiclereglbl.Size = new System.Drawing.Size(90, 13);
            this.vehiclereglbl.TabIndex = 3;
            this.vehiclereglbl.Text = "Vehicle Reg Num";
            // 
            // vehicleyearlbl
            // 
            this.vehicleyearlbl.AutoSize = true;
            this.vehicleyearlbl.Location = new System.Drawing.Point(383, 67);
            this.vehicleyearlbl.Name = "vehicleyearlbl";
            this.vehicleyearlbl.Size = new System.Drawing.Size(67, 13);
            this.vehicleyearlbl.TabIndex = 4;
            this.vehicleyearlbl.Text = "Vehicle Year";
            // 
            // modellbl
            // 
            this.modellbl.AutoSize = true;
            this.modellbl.Location = new System.Drawing.Point(124, 67);
            this.modellbl.Name = "modellbl";
            this.modellbl.Size = new System.Drawing.Size(74, 13);
            this.modellbl.TabIndex = 5;
            this.modellbl.Text = "Vehicle Model";
            // 
            // vehicletxt
            // 
            this.vehicletxt.Location = new System.Drawing.Point(16, 108);
            this.vehicletxt.Name = "vehicletxt";
            this.vehicletxt.Size = new System.Drawing.Size(100, 20);
            this.vehicletxt.TabIndex = 6;
            // 
            // modeltxt
            // 
            this.modeltxt.Location = new System.Drawing.Point(127, 108);
            this.modeltxt.Name = "modeltxt";
            this.modeltxt.Size = new System.Drawing.Size(100, 20);
            this.modeltxt.TabIndex = 7;
            // 
            // yeartxt
            // 
            this.yeartxt.Location = new System.Drawing.Point(386, 108);
            this.yeartxt.Name = "yeartxt";
            this.yeartxt.Size = new System.Drawing.Size(100, 20);
            this.yeartxt.TabIndex = 8;
            // 
            // regnumtxt
            // 
            this.regnumtxt.Location = new System.Drawing.Point(246, 108);
            this.regnumtxt.Name = "regnumtxt";
            this.regnumtxt.Size = new System.Drawing.Size(100, 20);
            this.regnumtxt.TabIndex = 9;
            // 
            // outputlist
            // 
            this.outputlist.FormattingEnabled = true;
            this.outputlist.Location = new System.Drawing.Point(433, 302);
            this.outputlist.Name = "outputlist";
            this.outputlist.Size = new System.Drawing.Size(301, 160);
            this.outputlist.TabIndex = 10;
            // 
            // journeytitle
            // 
            this.journeytitle.AutoSize = true;
            this.journeytitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.journeytitle.Location = new System.Drawing.Point(13, 166);
            this.journeytitle.Name = "journeytitle";
            this.journeytitle.Size = new System.Drawing.Size(98, 29);
            this.journeytitle.TabIndex = 11;
            this.journeytitle.Text = "Journey";
            // 
            // distancetraveledlbl
            // 
            this.distancetraveledlbl.AutoSize = true;
            this.distancetraveledlbl.Location = new System.Drawing.Point(12, 222);
            this.distancetraveledlbl.Name = "distancetraveledlbl";
            this.distancetraveledlbl.Size = new System.Drawing.Size(94, 13);
            this.distancetraveledlbl.TabIndex = 12;
            this.distancetraveledlbl.Text = "Distance Traveled";
            // 
            // vehicletitle
            // 
            this.vehicletitle.AutoSize = true;
            this.vehicletitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.vehicletitle.Location = new System.Drawing.Point(12, 9);
            this.vehicletitle.Name = "vehicletitle";
            this.vehicletitle.Size = new System.Drawing.Size(93, 29);
            this.vehicletitle.TabIndex = 13;
            this.vehicletitle.Text = "Vehicle";
            // 
            // fuelusedlbl
            // 
            this.fuelusedlbl.AutoSize = true;
            this.fuelusedlbl.Location = new System.Drawing.Point(143, 222);
            this.fuelusedlbl.Name = "fuelusedlbl";
            this.fuelusedlbl.Size = new System.Drawing.Size(55, 13);
            this.fuelusedlbl.TabIndex = 14;
            this.fuelusedlbl.Text = "Fuel Used";
            // 
            // fuelusetxt
            // 
            this.fuelusetxt.Location = new System.Drawing.Point(146, 268);
            this.fuelusetxt.Name = "fuelusetxt";
            this.fuelusetxt.Size = new System.Drawing.Size(100, 20);
            this.fuelusetxt.TabIndex = 15;
            // 
            // traveledtxt
            // 
            this.traveledtxt.Location = new System.Drawing.Point(17, 268);
            this.traveledtxt.Name = "traveledtxt";
            this.traveledtxt.Size = new System.Drawing.Size(100, 20);
            this.traveledtxt.TabIndex = 16;
            // 
            // vehiclelistbox
            // 
            this.vehiclelistbox.FormattingEnabled = true;
            this.vehiclelistbox.Location = new System.Drawing.Point(516, 107);
            this.vehiclelistbox.Name = "vehiclelistbox";
            this.vehiclelistbox.Size = new System.Drawing.Size(268, 21);
            this.vehiclelistbox.TabIndex = 17;
            this.vehiclelistbox.SelectedIndexChanged += new System.EventHandler(this.vehiclelistbox_SelectedIndexChanged);
            // 
            // Addbtn
            // 
            this.Addbtn.Location = new System.Drawing.Point(17, 340);
            this.Addbtn.Name = "Addbtn";
            this.Addbtn.Size = new System.Drawing.Size(75, 23);
            this.Addbtn.TabIndex = 18;
            this.Addbtn.Text = "Add Journey";
            this.Addbtn.UseVisualStyleBackColor = true;
            this.Addbtn.Click += new System.EventHandler(this.Addbtn_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(592, 232);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "test data";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(592, 273);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 20;
            this.button2.Text = "test data";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(698, 232);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 21;
            this.button3.Text = "Clear";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(277, 222);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(69, 13);
            this.label1.TabIndex = 22;
            this.label1.Text = "Days Rented";
            // 
            // daysrentedtxt
            // 
            this.daysrentedtxt.Location = new System.Drawing.Point(280, 268);
            this.daysrentedtxt.Name = "daysrentedtxt";
            this.daysrentedtxt.Size = new System.Drawing.Size(100, 20);
            this.daysrentedtxt.TabIndex = 23;
            // 
            // Servicebtn
            // 
            this.Servicebtn.Location = new System.Drawing.Point(146, 340);
            this.Servicebtn.Name = "Servicebtn";
            this.Servicebtn.Size = new System.Drawing.Size(75, 23);
            this.Servicebtn.TabIndex = 24;
            this.Servicebtn.Text = "Service";
            this.Servicebtn.UseVisualStyleBackColor = true;
            this.Servicebtn.Click += new System.EventHandler(this.Servicebtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 619);
            this.Controls.Add(this.Servicebtn);
            this.Controls.Add(this.daysrentedtxt);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Addbtn);
            this.Controls.Add(this.vehiclelistbox);
            this.Controls.Add(this.traveledtxt);
            this.Controls.Add(this.fuelusetxt);
            this.Controls.Add(this.fuelusedlbl);
            this.Controls.Add(this.vehicletitle);
            this.Controls.Add(this.distancetraveledlbl);
            this.Controls.Add(this.journeytitle);
            this.Controls.Add(this.outputlist);
            this.Controls.Add(this.regnumtxt);
            this.Controls.Add(this.yeartxt);
            this.Controls.Add(this.modeltxt);
            this.Controls.Add(this.vehicletxt);
            this.Controls.Add(this.modellbl);
            this.Controls.Add(this.vehicleyearlbl);
            this.Controls.Add(this.vehiclereglbl);
            this.Controls.Add(this.vehiclelbl);
            this.Controls.Add(this.Savebtn);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Savebtn;
        private System.Windows.Forms.Label vehiclelbl;
        private System.Windows.Forms.Label vehiclereglbl;
        private System.Windows.Forms.Label vehicleyearlbl;
        private System.Windows.Forms.Label modellbl;
        private System.Windows.Forms.TextBox vehicletxt;
        private System.Windows.Forms.TextBox modeltxt;
        private System.Windows.Forms.TextBox yeartxt;
        private System.Windows.Forms.TextBox regnumtxt;
        private System.Windows.Forms.ListBox outputlist;
        private System.Windows.Forms.Label journeytitle;
        private System.Windows.Forms.Label distancetraveledlbl;
        private System.Windows.Forms.Label vehicletitle;
        private System.Windows.Forms.Label fuelusedlbl;
        private System.Windows.Forms.TextBox fuelusetxt;
        private System.Windows.Forms.TextBox traveledtxt;
        private System.Windows.Forms.ComboBox vehiclelistbox;
        private System.Windows.Forms.Button Addbtn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox daysrentedtxt;
        private System.Windows.Forms.Button Servicebtn;
    }
}

