﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    public class Service
    {
      
        private bool service;
        
        //constructors
        public Service()
        {
        }

        public Service( bool pservice)
        {
           
            service = pservice;
        }

      //get set

        public bool getservice
        {
            get { return (service); }
            set { service = value; }
        }
  
       

    }
}
