﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace Phase_One
{
    public partial class Form1 : Form
    {
       
        vehicle[] vehicleList = new vehicle[5];
        int cnt = 0;
        bool service;
        int servicekm;
        

        public Form1()
        {

            InitializeComponent();

        }

        private void Servicebtn_Click(object sender, EventArgs e)
        {
            if (vehiclelistbox.SelectedIndex != -1)
            {
                vehicleList[vehiclelistbox.SelectedIndex].gettotalservice += 1;
                vehicleList[vehiclelistbox.SelectedIndex].getservicekm = vehicleList[vehiclelistbox.SelectedIndex].getotalkm;
                vehicleList[vehiclelistbox.SelectedIndex].getReqService = false;
            }
        }

        private void vehiclelistbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            vehicletxt.Text = vehicleList[vehiclelistbox.SelectedIndex].getmake;
            modeltxt.Text = vehicleList[vehiclelistbox.SelectedIndex].getmodel;
            regnumtxt.Text = vehicleList[vehiclelistbox.SelectedIndex].getreg;
            yeartxt.Text = vehicleList[vehiclelistbox.SelectedIndex].getyear;
        
        }

        private void Savebtn_Click(object sender, EventArgs e)
        {

            try
            {
                vehicleList[cnt] = new vehicle(vehicletxt.Text, modeltxt.Text, regnumtxt.Text, yeartxt.Text);
                vehiclelistbox.Items.Add(vehicleList[cnt].ToString());
                cnt++;
            }

            catch(Exception ex)
            {
                outputlist.Items.Add("An error occured");
                outputlist.Items.Add(ex);
                
            }
        }

        private void Addbtn_Click(object sender, EventArgs e)
        {
            if (vehicleList[vehiclelistbox.SelectedIndex].getReqService == true)
            {
                MessageBox.Show("Vehicle cannot be rented due to srvice required");
            }
            else
            {
                if (string.IsNullOrEmpty(traveledtxt.Text) || string.IsNullOrEmpty(fuelusetxt.Text))
                {
                    outputlist.Items.Add("You didn't enter a journey distance");
                }

                if (vehiclelistbox.SelectedIndex != -1)
                {
                    outputlist.Items.Add("Select a vehicle");

                }

                if (vehicleList[vehiclelistbox.SelectedIndex].getotalkm - vehicleList[vehiclelistbox.SelectedIndex].getservicekm > 99)
                {
                    MessageBox.Show("Service required");
                    Service serv1 = new Service(true);
                    vehicleList[vehiclelistbox.SelectedIndex].requiresService(serv1);
                }

                else

                {
                    try
                    {
                        fuelpurchase purchase1 = new fuelpurchase(0, 0, Convert.ToInt32(fuelusetxt.Text));
                        Journey journey1 = new Journey(Convert.ToInt32(traveledtxt.Text));
                        PerKmRental kmrental = new PerKmRental();
                        PerDayRental drental = new PerDayRental(Convert.ToInt32(daysrentedtxt.Text), 100);

                        vehicleList[vehiclelistbox.SelectedIndex].addjourney(journey1);
                        outputlist.Items.Clear();


                        outputlist.Items.Add("Make: " + vehicleList[vehiclelistbox.SelectedIndex].getmake);
                        outputlist.Items.Add("Model: " + vehicleList[vehiclelistbox.SelectedIndex].getmodel);
                        outputlist.Items.Add("Reg: " + vehicleList[vehiclelistbox.SelectedIndex].getreg);
                        outputlist.Items.Add("Year: " + vehicleList[vehiclelistbox.SelectedIndex].getyear);
                        outputlist.Items.Add("Total Km: " + vehicleList[vehiclelistbox.SelectedIndex].getotalkm);
                        outputlist.Items.Add("Fuel Econonmy Km/L " + (vehicleList[vehiclelistbox.SelectedIndex].getotalkm) / purchase1.getfuelused);
                        int totalkmr = (vehicleList[vehiclelistbox.SelectedIndex].getotalkm * kmrental.getcostperkm);
                        int totaldayr = (Convert.ToInt32(daysrentedtxt.Text) * Convert.ToInt32(drental.getcostperday));
                        outputlist.Items.Add("Total Servies:" + vehicleList[vehiclelistbox.SelectedIndex].gettotalservice);
                        outputlist.Items.Add("Total Income" + (Convert.ToInt32(vehicleList[vehiclelistbox.SelectedIndex].getotalkm) * kmrental.getcostperkm + Convert.ToInt32(drental.getdaysrented * drental.getcostperday)));
                        outputlist.Items.Add("Km Since last service: " + (vehicleList[vehiclelistbox.SelectedIndex].getservicekm));
                    

                    }
                    catch (Exception x)
                    {
                        outputlist.Items.Clear();
                        outputlist.Items.Add(x);
                    }


                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            vehicletxt.Text = "ford";
            modeltxt.Text = "focus";
            regnumtxt.Text = "5hdf 53f";
            yeartxt.Text = "1990";

        }

        private void button2_Click(object sender, EventArgs e)
        {
            vehicletxt.Text = "holden";
            modeltxt.Text = "commodore";
            regnumtxt.Text = "12hs 6dfv";
            yeartxt.Text = "2006";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            vehicletxt.Text = "";
            modeltxt.Text = "";
            regnumtxt.Text = "";
            yeartxt.Text = "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
