﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    public class Service
    {
      
        private bool service;
        

        public Service()
        {
        }

        public Service( bool pservice)
        {
           
            service = pservice;
        }

      

        public bool getservice
        {
            get { return (service); }
            set { service = value; }
        }
  
       

    }
}
