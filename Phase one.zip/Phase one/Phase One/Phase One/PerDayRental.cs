﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phase_One
{
    class PerDayRental
    {
        private int daysrented;
        private int costperday = 100;

        public PerDayRental()
        { }

        public PerDayRental(int pdaysrented, int pcostperday)
        {
            daysrented = pdaysrented;
            costperday = pcostperday;
        }


        public int getdaysrented
        {
            get { return (daysrented); }
            set { daysrented = value; }
        }

        public int getcostperday
        {
            get { return (costperday); }
            set { costperday = value; }
        }

    }
}
